import gzip
import hashlib
import json
import shutil
from pathlib import Path

base=Path('results')
destination=Path('docs/validation/2026-10-08/retained-windows')
raw=destination/'raw'
raw.mkdir(exist_ok=True)
records=[]
def digest(data):
    return hashlib.sha256(data).hexdigest()
def archive(source,relative):
    data=source.read_bytes()
    compressed=gzip.compress(data,compresslevel=9,mtime=0)
    path=raw/(relative+'.gz')
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(compressed)
    records.append({'path':path.relative_to(destination).as_posix(),'original_bytes':len(data),'original_sha256':digest(data),'gzip_sha256':digest(compressed)})
runs={
 'rows':('retained-windows-20261008','af8f9d566fe545a80053a05df6a49c4d5cfbfb94',37714277802),
 'rectangles':('rect-windows-20261008','e69e78a9ace618d415557e5713ecffc4557a07d8',37715631523),
}
provenance={'previous_revision':'c3748990ffa02a51948de25a9940ffeb536b557f','runs':{}}
for label,(directory,revision,ci) in runs.items():
    root=base/directory
    for p in sorted((root/'remote').rglob('*')):
        if p.is_file() and p.suffix in {'.json','.jsonl','.log','.cpp','.py'}:
            archive(p,label+'/'+p.relative_to(root/'remote').as_posix())
    for p in sorted(root.glob('*.ps1')):
        archive(p,label+'/local/'+p.name)
    shutil.copy2(root/'summary.json',destination/(label+'-summary.json'))
    server=json.loads((root/'remote/delegate-server.json').read_text(encoding='utf-8-sig'))
    provenance['runs'][label]={
      'runtime_source_revision':revision,
      'private_ci_run':f'https://github.com/t8/npu-render/actions/runs/{ci}',
      'renderer_executable_sha256':server['renderer_sha256'].lower(),
      'tahoma_executable_sha256':server['binary_sha256'].lower(),
      'executed_sources':{p:digest((root/'remote'/p).read_bytes()) for p in ['desktop_delegate.cpp','benchmark_delegate.py']},
    }
sources=['native/windows/live_renderer.hpp','native/windows/d3d12_buffers.hpp','native/windows/blend_model.hpp','native/windows/opaque_model.hpp','native/tools/windows_route_probe.cpp','native/tools/gpu_power_probe.cpp','tools/windows_gpu_telemetry.ps1','research/analyze_native_cost.py','research/analyze_delegate.py']
provenance.update({
  'shared_sources_sha256':{s:digest(Path(s).read_bytes()) for s in sources},
  'igcl_source_revision':'b6c462933502e13d1537dd5024949a51be30e63d',
  'package_installation':'raw/rectangles/bundle-installation.json.gz',
  'notes':[
   'Raw files preserve their original bytes and encoding inside deterministic gzip files.',
   'The rectangle experiment started only after row experiment cleanup completed.',
   'No build, extra graphics test or bundle upload ran on Delta during either measured experiment.',
   'The direct-LUID route probe was rerun between experiments and copied into both capture directories; adapter identities matched IGCL on the same boot.',
   'No driver, power plan, clock, fan or security settings were changed.',
   'The earlier full-clear prototype has qualification captures but no frozen source snapshot; it is excluded from both sustained comparisons.',
   'No desktop screenshots, binary artifacts, model weights, caches or private network addresses are retained.',
   'The installed experimental bundle is isolated; the existing launcher and previous application builds remain unchanged.',
   'The first final-state capture expanded PowerShell string metadata; it is preserved unchanged. final-state-verified.json uses a plain file string and is the compact final state check.'
  ]
})
archive(Path(__file__),'local/archive-evidence.py')
(destination/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
names=['rows-summary.json','rectangles-summary.json','provenance.json']
(destination/'manifest.json').write_text(json.dumps({'raw_files':records,'derived_files':{name:digest((destination/name).read_bytes()) for name in names}},indent=2)+'\n')
print('archived',len(records),'raw files')
