$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$out=Join-Path $env:LOCALAPPDATA 'npu-render\checks\rect-windows-20261008'
$old=Join-Path $env:LOCALAPPDATA 'npu-render\builds\ci-ee4d711\npu-render\nr_native_live.exe'
$delegate=Join-Path $env:LOCALAPPDATA 'npu-render\builds\ci-bda4b98\npu-render\nr_desktop_delegate.exe'
$processes=@(Get-Process -Name nr_delegate_retained,nr_delegate_rect,nr_desktop_delegate,nr_gpu_power_probe,cascadia-ov -ErrorAction SilentlyContinue | Select-Object Id,ProcessName)
$tasks=@(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object {$_.TaskName -like 'NpuRender-*20261008*'} | Select-Object TaskName,State)
$ports=@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object {$_.LocalPort -in @(18080,19100)} | Select-Object LocalPort,OwningProcess)
$oldHash=(Get-FileHash $old -Algorithm SHA256).Hash.ToLower()
$delegateHash=(Get-FileHash $delegate -Algorithm SHA256).Hash.ToLower()
if ($oldHash -ne '2a1165c7fb08b989c4a97c0d00bd9fe8ca6df7d7709044b1227d2c643c17b5fd') { throw 'Prior application build changed' }
if ($delegateHash -ne 'd01b07a7631e84899d550521b8d41568e91f36601d5c77a0ff7de289181d58f9') { throw 'Prior delegate build changed' }
if ($processes.Count -or $tasks.Count -or $ports.Count) { throw 'Experiment resources remain active' }
@{checked_utc=[DateTime]::UtcNow.ToString('o');boot=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o');battery_percent=(Get-CimInstance Win32_Battery).EstimatedChargeRemaining;battery=@(Get-CimInstance -Namespace root/wmi -ClassName BatteryStatus | Select-Object PowerOnline,Charging,Discharging,RemainingCapacity);remaining_processes=$processes;remaining_tasks=$tasks;remaining_test_listeners=$ports;prior_application_sha256=$oldHash;prior_delegate_sha256=$delegateHash;existing_launcher=[System.IO.File]::ReadAllText((Join-Path $env:LOCALAPPDATA 'npu-render\run-delegate.cmd'));power_scheme=(powercfg /getactivescheme | Out-String).Trim()} | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 (Join-Path $out 'final-state-verified.json')
Write-Output 'Final state verified; prior builds unchanged and experiment resources stopped'
