$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:LOCALAPPDATA 'Temp\npu-graphics-probe-0146a2388f25'
$out=Join-Path $env:LOCALAPPDATA 'npu-render\checks\rect-windows-20261008'
$zip=Join-Path $root 'npu-render-ci-e69e78a.zip'
$build=Join-Path $env:LOCALAPPDATA 'npu-render\builds\ci-e69e78a'
$installed=Join-Path $build 'npu-render'
$task='NpuRender-Rect-Bundle-20261008'
$expectedZip='0647a29f2138386e8ed20f44abc8d07d0aeaa6fa722fa15add7402b57f1d403c'
if ((Get-FileHash $zip -Algorithm SHA256).Hash.ToLower() -ne $expectedZip) { throw 'Archive checksum mismatch' }
if (Test-Path $build) { throw 'Isolated build destination already exists' }
Expand-Archive -LiteralPath $zip -DestinationPath $build
$manifest=Get-Content (Join-Path $installed 'manifest.json') -Raw | ConvertFrom-Json
if ($manifest.source_revision -ne 'e69e78a9ace618d415557e5713ecffc4557a07d8') { throw 'Source revision mismatch' }
$count=0
foreach ($file in $manifest.sha256.PSObject.Properties) {
 if ((Get-FileHash (Join-Path $installed $file.Name) -Algorithm SHA256).Hash.ToLower() -ne $file.Value) { throw ('Manifest mismatch: '+$file.Name) }
 $count++
}
$code=@'
import os,sys,subprocess,json
from pathlib import Path
installed,out=map(Path,sys.argv[1:])
os.environ['PATH']=str(installed/'runtime')+os.pathsep+os.environ['PATH']
for width,height in [(640,360),(1920,1080)]:
    report=out/f'bundle-qualification-{width}x{height}.json'
    command=[str(installed/'nr_desktop_delegate.exe'),'--validate-only','--placement','retained-rect','--width',str(width),'--height',str(height),'--expected-npu-driver','1005540','--report',str(report)]
    result=subprocess.run(command,timeout=120)
    if result.returncode: raise SystemExit(result.returncode)
    r=json.loads(report.read_text())
    assert r['passed'] and r['opaque_oracle_max_error']==0 and r['validation_only']
report=out/'bundle-switch.json'
command=[str(installed/'nr_desktop_delegate.exe'),'--mode','DWM','--placement','retained-rect','--fps','30','--sequence','NPU,INVALID,GPU,DWM','--switch-every','2.5','--seconds','13','--expected-npu-driver','1005540','--report',str(report)]
result=subprocess.run(command,timeout=120)
if result.returncode: raise SystemExit(result.returncode)
r=json.loads(report.read_text())
assert r['placement_provider']=='retained-rect' and not r['skipped_slots']
assert all(f['host_uploaded_bytes']==0 for f in r['frames'])
assert r['passed'] and r['restored_source_windows']==3 and r['end_screen_max_error']==0
assert all(c['maximum_rgb_error']==0 for c in r['screen_checks'])
accepted=[s['requested'] for s in r['selections'] if s['accepted']]
assert accepted==['DWM','NPU','GPU','DWM'],accepted
rejected=[s for s in r['selections'] if not s['accepted']]
assert len(rejected)==1 and rejected[0]['retained']=='NPU'
assert all(f['visible_source_windows']==(3 if f['mode']=='DWM' else 0) for f in r['frames'])
print('Packaged visible handoff and source restoration passed',flush=True)
'@
try {
 $job=Join-Path $out 'bundle-switch.job.json'
 @{command=@((Join-Path $root 'venv\Scripts\python.exe'),'-c',$code,$installed,$out);log=(Join-Path $out 'bundle-switch.log')} | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 $job
 $action=New-ScheduledTaskAction -Execute (Join-Path $root 'venv\Scripts\pythonw.exe') -Argument ('"'+(Join-Path $root 'native_runner.py')+'" "'+$job+'"')
 $principal=New-ScheduledTaskPrincipal -UserId ($env:COMPUTERNAME+'\tatef') -LogonType Interactive -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 7) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
 Register-ScheduledTask -TaskName $task -Action $action -Principal $principal -Settings $settings | Out-Null
 Start-ScheduledTask -TaskName $task
 $deadline=(Get-Date).AddSeconds(400)
 do { Start-Sleep -Seconds 3; $state=(Get-ScheduledTask -TaskName $task).State } while ($state -eq 'Running' -and (Get-Date) -lt $deadline)
 if ($state -eq 'Running') { throw 'Package check timed out' }
 Get-Content (Join-Path $out 'bundle-switch.log') -Tail 12
 if ((Get-ScheduledTaskInfo -TaskName $task).LastTaskResult -ne 0) { throw 'Package check failed' }
 @{source_revision=$manifest.source_revision;bundle_sha256=$expectedZip;verified_files=$count;installed_directory=$installed;executable_sha256=(Get-FileHash (Join-Path $installed 'nr_desktop_delegate.exe') -Algorithm SHA256).Hash.ToLower();checked_utc=[DateTime]::UtcNow.ToString('o');passed=$true} | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $out 'bundle-installation.json')
} finally {
 Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
 Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
}
