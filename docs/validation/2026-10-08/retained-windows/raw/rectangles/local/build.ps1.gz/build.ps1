$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:LOCALAPPDATA 'Temp\npu-graphics-probe-0146a2388f25'
$out=Join-Path $env:LOCALAPPDATA 'npu-render\checks\rect-windows-20261008'
$build=Join-Path $env:LOCALAPPDATA 'npu-render\builds\native-retained'
New-Item -ItemType Directory -Force -Path $out | Out-Null
if (Get-Process nr_delegate_retained -ErrorAction SilentlyContinue) { throw 'Previous experiment still running' }
& 'C:\Program Files\CMake\bin\cmake.exe' --build $build --config Release --target nr_desktop_delegate nr_windows_route_probe *> (Join-Path $out 'build.log')
if ($LASTEXITCODE) { Get-Content (Join-Path $out 'build.log') -Tail 20; throw 'build failed' }
Copy-Item (Join-Path $build 'Release\nr_desktop_delegate.exe') (Join-Path $root 'nr_delegate_rect.exe')
Copy-Item (Join-Path $root 'native\windows\desktop_delegate.cpp') (Join-Path $out 'desktop_delegate.cpp')
Copy-Item (Join-Path $root 'benchmark_delegate.py') (Join-Path $out 'benchmark_delegate.py')
$env:PATH=(Join-Path $root 'venv\Lib\site-packages\openvino\libs')+';'+$env:PATH
& (Join-Path $build 'Release\nr_windows_route_probe.exe') | Set-Content -Encoding UTF8 (Join-Path $out 'windows-route.json')
if ($LASTEXITCODE) { throw 'route probe failed' }
Copy-Item (Join-Path $out 'windows-route.json') (Join-Path $env:LOCALAPPDATA 'npu-render\checks\retained-windows-20261008\windows-route.json')
@{utc=[DateTime]::UtcNow.ToString('o');boot=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToUniversalTime().ToString('o');battery=(Get-CimInstance Win32_Battery).EstimatedChargeRemaining;sha256=(Get-FileHash (Join-Path $root 'nr_delegate_rect.exe')).Hash} | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $out 'preflight.json')
# Pixel qualification rejects bad buffer pitch, coordinate or driver behavior.
$p=Start-Process -FilePath (Join-Path $root 'nr_delegate_rect.exe') -ArgumentList @('--validate-only','--placement','retained-rect','--expected-npu-driver','1005540','--report',(Join-Path $out 'qualification.json')) -Wait -PassThru -RedirectStandardOutput (Join-Path $out 'qualification.stdout.log') -RedirectStandardError (Join-Path $out 'qualification.stderr.log')
Get-Content (Join-Path $out 'qualification.stderr.log') -Tail 12
Get-Content (Join-Path $out 'qualification.stdout.log') -Tail 5
if ($p.ExitCode) { throw 'pixel qualification failed' }
