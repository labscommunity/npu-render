param([Parameter(Mandatory=$true)][string]$Root)
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$r="$env:LOCALAPPDATA\npu-render";$probe="$r\builds\native-present-v6\Release\nr_frame_present_probe.exe"
$proof=Get-Content "$r\builds\native-present-v6\build-report.json" -Raw|ConvertFrom-Json
if(!$proof.clean_build -or (Get-FileHash $probe).Hash -ne $proof.binary_sha256){throw 'Observer binary mismatch'}
$started=[DateTime]::UtcNow;$deadline=$started.AddMinutes(8);$samples=0;$failed=0
while([DateTime]::UtcNow -lt $deadline -and !(Test-Path "$Root\stop")){
 $observed=[DateTime]::UtcNow.ToString('o');$raw=& $probe --inspect-topology 2> "$Root\last-stderr.log";$code=$LASTEXITCODE
 $entries=@();foreach($line in $raw){try{$entries+=($line|ConvertFrom-Json)}catch{}}
 $event=[ordered]@{observed=$observed;exit_code=$code;entries=$entries};$event|ConvertTo-Json -Depth 5 -Compress|Add-Content -Encoding UTF8 "$Root\samples.jsonl";$samples++;if($code){$failed++}
 Start-Sleep -Seconds 2
}
[ordered]@{started=$started.ToString('o');finished=[DateTime]::UtcNow.ToString('o');completed=$true;passed=($samples -gt 0 -and $failed -eq 0);samples=$samples;failed_samples=$failed;display_changed=$false;probe_sha256=$proof.binary_sha256}|ConvertTo-Json|Set-Content "$Root\report.json"
