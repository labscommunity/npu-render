$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$r="$env:LOCALAPPDATA\npu-render";$out="$r\vm\native-topology-v2";$task='T8-NpuRender-InspectTopology-V2'
if((Test-Path $out) -or (Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue)){throw 'Inspection identity exists'}
New-Item -ItemType Directory $out|Out-Null
$source=Get-Content "$r\vm\native-topology-v2-source.json" -Raw|ConvertFrom-Json
foreach($f in $source.psobject.Properties){if((Get-FileHash "$r\vm\$($f.Name)").Hash -ne $f.Value){throw 'Observer source mismatch'}}
$action=New-ScheduledTaskAction -Execute "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy RemoteSigned -File "'+$r+'\vm\observe-native-topology-v2.ps1" -Root "'+$out+'"')
$principal=New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().User.Value) -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 9) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName $task -Action $action -Principal $principal -Settings $settings|Out-Null
Start-ScheduledTask -TaskName $task
$deadline=[DateTime]::UtcNow.AddSeconds(15)
while(!(Test-Path "$out\samples.jsonl") -and [DateTime]::UtcNow -lt $deadline){Start-Sleep -Milliseconds 200}
if(!(Test-Path "$out\samples.jsonl")){throw 'Observer did not start'}
Get-Content "$out\samples.jsonl" -Tail 1
