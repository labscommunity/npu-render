"""Replay a captured draw through the C++ local client and NPU worker."""
import argparse,os,subprocess,time,json,secrets,struct,hashlib,traceback
from pathlib import Path
from datetime import UTC,datetime
H=struct.Struct('<3Q14I');R=struct.Struct('<5Q2I')
def obj(p):
 b=p.read_bytes();return json.loads(b.decode('utf-16') if b.startswith(b'\xff\xfe') else b.decode('utf-8-sig'))
def rows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.startswith('{') and x.endswith('}')]
p=argparse.ArgumentParser()
for x in ('worker','client','emitter','runtime','cache','output'):p.add_argument('--'+x,type=Path,required=True)
v=p.parse_args();v.output.mkdir(exist_ok=False);out=v.output
for binary in (v.worker,v.client,v.emitter):
 b=obj(binary.parent.parent/'registered-build-report.json');assert b['clean_build'] and hashlib.sha256(binary.read_bytes()).hexdigest()==b['binary_sha256'][binary.name].lower()
env=os.environ.copy();env['PATH']=str(v.runtime)+os.pathsep+env.get('PATH','');env.update(NR_RENDER_NPU_CACHE=str(v.cache),NR_RENDER_SHARED_QUEUE='1',NR_RENDER_PIPELINE_CACHE='expanded',NR_RENDER_MEMORY_CACHE='1',NR_RENDER_COMPACT_COVERAGE='0')
report=dict(started=datetime.now(UTC).isoformat(),completed=False,passed=False,driver_installed=False,desktop_changed=False)
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save();worker=None
try:
 emitted=subprocess.run([str(v.emitter),'--emit',str(out/'request.bin')],env=env,capture_output=True,timeout=30);(out/'emit.stdout.jsonl').write_bytes(emitted.stdout);(out/'emit.stderr.log').write_bytes(emitted.stderr)
 assert emitted.returncode==0 and not emitted.stderr;report['packet_contract']=json.loads(emitted.stdout);save()
 request=(out/'request.bin').read_bytes();h=list(H.unpack_from(request));assert h[3]==20 and h[4:6]==[2880,1800] and h[16]==13
 pipe=r'\\.\pipe\npu-render-indexed-'+secrets.token_hex(16)
 with (out/'worker.stdout.jsonl').open('xb') as stdout,(out/'worker.stderr.log').open('xb') as stderr:
  worker=subprocess.Popen([str(v.worker),pipe,'1','120'],env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW);report['worker_pid']=worker.pid;save()
  deadline=time.perf_counter()+15
  while not any(x.get('local_worker_ready') for x in rows(out/'worker.stdout.jsonl')):
   assert worker.poll() is None and time.perf_counter()<deadline;time.sleep(.02)
  result=subprocess.run([str(v.client),pipe,str(worker.pid),str(out/'request.bin'),str(out/'reply.bin'),'60000','success'],env=env,capture_output=True,timeout=70);(out/'client.stdout.jsonl').write_bytes(result.stdout);(out/'client.stderr.log').write_bytes(result.stderr)
  assert result.returncode==0 and not result.stderr;client=json.loads(result.stdout);assert client['native_client_success'];h[13]=client['client_pid']
  reply=(out/'reply.bin').read_bytes();rh=list(H.unpack_from(reply));assert all(h[i]==rh[i] for i in range(17) if i not in (12,14,15)) and rh[14:16]==[2,3] and len(reply)==128+2880*1800*4
  reference=bytes([191,64,0,255])*(2880*1800);assert reply[128:]==reference
  worker.wait(timeout=10);evidence=rows(out/'worker.stdout.jsonl');renders=[x for x in evidence if x.get('passed')];acks=[x for x in evidence if x.get('worker_success')];done=[x for x in evidence if x.get('local_worker_finished')]
  assert worker.returncode==0 and len(renders)==len(acks)==len(done)==1 and renders[0]['client_pid']==client['client_pid'] and renders[0]['execution_device']=='NPU' and done[0]['succeeded']==done[0]['settled']==1 and not (out/'worker.stderr.log').read_bytes()
  report.update(passed=True,client_pid=client['client_pid'],abi=20,legacy_abi=13,request_bytes=len(request),reply_bytes=len(reply),npu_operation_receipts=1,delivery_acknowledgments=1,pixels_match_cpu_reference=True,verified_components=len(reference),pixels_sha256=hashlib.sha256(reply[128:]).hexdigest(),receipt=list(R.unpack_from(reply,80)),worker_exit_code=0)
except Exception as error:report.update(error=repr(error),traceback=traceback.format_exc())
finally:
 if worker is not None and worker.poll() is None:worker.kill();worker.wait(timeout=5);report['owned_worker_terminated']=True
 report.update(completed=True,finished=datetime.now(UTC).isoformat());save()
print(json.dumps(report));raise SystemExit(0 if report['passed'] else 1)
