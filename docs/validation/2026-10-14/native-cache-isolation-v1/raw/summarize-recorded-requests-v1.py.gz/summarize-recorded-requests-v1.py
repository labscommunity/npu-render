import argparse,json,struct,statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('bootstrap',type=Path);p.add_argument('output',type=Path);v=p.parse_args();v.output.mkdir(exist_ok=False)
def rows(path):return [json.loads(x) for x in path.read_text().splitlines() if x.startswith('{') and x.endswith('}')]
worker=rows(v.bootstrap/'worker.stdout.jsonl');renders=[x for x in worker if x.get('passed')];ack={x['dispatch_ticket']:x for x in worker if x.get('worker_success')};items=[];headers=struct.Struct('<3Q14I')
for ticket,render in enumerate(renders):
 with (v.bootstrap/'requests'/f'request-{ticket:08d}.bin').open('rb') as source:h=headers.unpack(source.read(80))
 assert h[11]==render['sequence'] and h[13]==render['client_pid'];item=dict(ticket=ticket,abi=h[3],width=h[4],height=h[5],vertices=h[6],flags=h[8],**{k:render[k] for k in ('provider_requests','draw_ms','compile_and_draw_ms','compile_calls','backend_compile_calls','memory_cache_hits','memory_cache_evictions')});item['delivery_acknowledged']=ticket in ack;items.append(item)
report=dict(completed_operation_count=len(items),slowest_operations=sorted(items,key=lambda x:x['compile_and_draw_ms'],reverse=True)[:15],total_provider_requests=sum(x['provider_requests'] for x in items),total_draw_ms=sum(x['draw_ms'] for x in items),total_compile_and_draw_ms=sum(x['compile_and_draw_ms'] for x in items),performance_measurement_valid=False,contains_private_pixels=False,desktop_offloaded=False)
(v.output/'operations.json').write_text(json.dumps(items,indent=2)+'\n');(v.output/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
