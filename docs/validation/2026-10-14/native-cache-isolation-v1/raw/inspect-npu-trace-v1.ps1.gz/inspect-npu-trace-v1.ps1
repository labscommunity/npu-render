param([Parameter(Mandatory=$true)][ValidatePattern('^[a-z0-9-]+$')][string]$Trial)
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$r="$env:LOCALAPPDATA\npu-render";$root="$r\vm\$Trial-control";$out="$root\trace-summary";$trace="$root\npu.etl"
if(Test-Path $out){throw 'Trace summary exists'};$control=Get-Content "$root\report.json" -Raw|ConvertFrom-Json;$replay=Get-Content "$r\vm\$Trial\report.json" -Raw|ConvertFrom-Json
if(!$control.completed -or !$control.trace_stopped -or !$replay.completed){throw 'Trace is still active'}
New-Item -ItemType Directory $out|Out-Null
$counts=@{};$first=$null;$last=$null;$total=0;$owned=0;$bad=@();$tail=[Collections.Generic.Queue[object]]::new();$eventsFile="$out\selected-events.jsonl";$writer=[IO.StreamWriter]::new($eventsFile,$false,[Text.UTF8Encoding]::new($false))
try{
 Get-WinEvent -Path $trace -Oldest -ErrorAction Stop|ForEach-Object {
  $event=$_;++$total;if($total -gt 3000000){throw 'Event budget exceeded'}
  if($event.ProviderName -in @('Intel-NPU-LevelZero','Intel-NPU-Kmd')){
   $key="$($event.ProviderName):$($event.Id)";if(!$counts.ContainsKey($key)){$counts[$key]=0};++$counts[$key]
   $time=$event.TimeCreated.ToUniversalTime().ToString('o');if(!$first){$first=$time};$last=$time
   if($event.ProcessId -eq $replay.worker_pid){++$owned}
   $row=[ordered]@{time=$time;provider=$event.ProviderName;id=$event.Id;level=$event.Level;task=$event.Task;opcode=$event.Opcode;worker_process=($event.ProcessId -eq $replay.worker_pid);thread_id=$event.ThreadId}
   $tail.Enqueue($row);if($tail.Count -gt 40){[void]$tail.Dequeue()}
   if($event.Level -in @(1,2,3)){
    $xml=[xml]$event.ToXml();$fields=[ordered]@{};foreach($data in $xml.Event.EventData.Data){$name=[string]$data.Name;$value=[string]$data.'#text';if($name -match '(?i)handle|address|ptr|^h[A-Z]'){$value='<pointer omitted>'};$fields[$name]=$value};$row.fields=$fields
    $writer.WriteLine(($row|ConvertTo-Json -Depth 6 -Compress));$bad+=$row
   }
  }
 }
}finally{$writer.Dispose()}
$manifest=@(foreach($provider in @('Intel-NPU-LevelZero','Intel-NPU-Kmd')){(Get-WinEvent -ListProvider $provider).Events|Where-Object {$counts.ContainsKey("${provider}:$($_.Id)")}|ForEach-Object {[ordered]@{provider=$provider;id=$_.Id;description=$_.Description;level=[string]$_.Level;task=[string]$_.Task;opcode=[string]$_.Opcode}}})
$manifest|ConvertTo-Json -Depth 5|Set-Content "$out\event-types.json"
[ordered]@{trace_sha256=(Get-FileHash $trace).Hash;trace_bytes=(Get-Item $trace).Length;trace_complete=$true;total_events=$total;worker_events=$owned;first=$first;last=$last;counts=$counts;warning_error_events=$bad.Count;tail=@($tail.ToArray());raw_trace_committed=$false;desktop_offloaded=$false}|ConvertTo-Json -Depth 6|Set-Content "$out\report.json"
[ordered]@{total_events=$total;worker_events=$owned;warning_error_events=$bad.Count;first=$first;last=$last}|ConvertTo-Json
