$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$r="$env:LOCALAPPDATA\npu-render";$trace="$env:ProgramData\T8-NpuRender-NativeTraceV1";$out="$r\vm\native-routing-v20-qualification"
if((Test-Path $trace) -or (Test-Path $out)){throw 'Diagnostic evidence exists'}
if(@(Get-Process nr_registered_local_indexed_worker,nr_registered_indexed_worker,nr_registered_indexed_stream_worker -ErrorAction SilentlyContinue).Count){throw 'Another renderer active'}
New-Item -ItemType Directory $trace|Out-Null
$acl=New-Object System.Security.AccessControl.DirectorySecurity;$acl.SetSecurityDescriptorSddlForm('O:BAG:BAD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)');Set-Acl $trace -AclObject $acl
$capture="$r\vm\native-routing-v20-capture"
if(Test-Path $capture){throw 'Capture directory exists'};New-Item -ItemType Directory $capture|Out-Null
$acl=New-Object System.Security.AccessControl.DirectorySecurity;$acl.SetSecurityDescriptorSddlForm('O:BAG:BAD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)');Set-Acl $capture -AclObject $acl
$env:NR_RENDER_CAPTURE_DIRECTORY=$capture
try{
 Remove-Item Env:NR_RENDER_AFFINE_BATCH -ErrorAction SilentlyContinue;$env:NR_RENDER_SHARED_CORE='1';$env:NR_RENDER_OPAQUE_CROP='1'
 & "$r\toolchains\openvino-2026.4.1\Scripts\python.exe" "$r\vm\qualify-native-routing-v3.py" --worker "$r\builds\native-routing-v20\Release\nr_registered_local_indexed_worker.exe" --client "$r\builds\native-routing-v20\Release\nr_native_probe_ddi_test.exe" --runtime "$r\toolchains\openvino-2026.4.1\Lib\site-packages\openvino\libs" --cache "$r\vm\model-cache-2026-4-v209" --output $out --trace $trace
 if($LASTEXITCODE){throw 'Native diagnostic qualification failed'}
}finally{
 if(!(Test-Path $out)){New-Item -ItemType Directory $out|Out-Null}
 Copy-Item $trace "$out\native-trace" -Recurse
 $files=@(Get-ChildItem "$out\native-trace" -File|ForEach-Object {[ordered]@{name=$_.Name;bytes=$_.Length;sha256=(Get-FileHash $_.FullName).Hash}});$files|ConvertTo-Json -Depth 4|Set-Content "$out\trace-manifest.json"
 Remove-Item $trace -Recurse -Force
 [ordered]@{owned_directory_removed=!(Test-Path $trace);driver_installed=$false;desktop_changed=$false}|ConvertTo-Json|Set-Content "$out\cleanup.json"
}

$records=@(Get-Content "$capture\index.jsonl"|ForEach-Object {$_|ConvertFrom-Json});$requests=@($records|Where-Object request_recorded);$responses=@($records|Where-Object provider_response_recorded)
if($requests.Count -ne 10 -or $responses.Count -ne 10){throw 'Recording count mismatch'}
for($i=0;$i -lt 10;++$i){$a=$requests[$i];$b=$responses[$i];if($a.ticket -ne $i -or $b.ticket -ne $i -or (Get-FileHash "$capture\$($a.file)").Hash -ne $a.sha256){throw 'Recording integrity mismatch'}}
[ordered]@{passed=$true;requests=10;provider_responses=10;request_hashes_verified=$true;contains_private_pixels=$true;desktop_offloaded=$false}|ConvertTo-Json|Set-Content "$capture\report.json"
