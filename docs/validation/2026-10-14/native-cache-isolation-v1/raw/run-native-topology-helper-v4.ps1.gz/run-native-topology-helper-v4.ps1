param([ValidateSet('inspect','validate-extend','extend')][string]$Mode='inspect',[ValidatePattern('^[a-z0-9-]+$')][Parameter(Mandatory=$true)][string]$Trial,[ValidateRange(1,300)][int]$Seconds=60)
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$r="$env:LOCALAPPDATA\npu-render";$out="$r\vm\$Trial";$source="$env:LOCALAPPDATA\Temp\npu-graphics-probe-0146a2388f25";$task="T8-NpuRender-$Trial";$b="$r\builds\native-topology-control-v4";$registered=$false
if((Test-Path $out) -or (Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue)){throw 'Trial identity exists'}
$proof=Get-Content "$b\build-report.json" -Raw|ConvertFrom-Json;if(!$proof.clean_build -or (Get-FileHash "$b\Release\nr_native_topology.exe").Hash -ne $proof.binary_sha256){throw 'Topology helper identity mismatch'}
New-Item -ItemType Directory $out|Out-Null;Copy-Item "$b\build-report.json" "$out\build-report.json"
$command=@("$b\Release\nr_native_topology.exe",('--'+$Mode));if($Mode -eq 'extend'){$command+=([string]$Seconds)}
@{command=$command;log="$out\probe.log"}|ConvertTo-Json -Depth 4|Set-Content -Encoding UTF8 "$out\job.json"
$report=[ordered]@{started=[DateTime]::UtcNow.ToString('o');mode=$Mode;seconds=$Seconds;completed=$false;passed=$false}
try{
 $action=New-ScheduledTaskAction -Execute "$source\venv\Scripts\pythonw.exe" -Argument ('"'+$source+'\native_runner.py" "'+$out+'\job.json"')
 $principal=New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().User.Value) -LogonType Interactive -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 6) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
 Register-ScheduledTask -TaskName $task -Action $action -Principal $principal -Settings $settings|Out-Null;$registered=$true;Start-ScheduledTask -TaskName $task
 $deadline=[DateTime]::UtcNow.AddSeconds($Seconds+40)
 do{Start-Sleep -Milliseconds 250;$state=(Get-ScheduledTask -TaskName $task).State;$info=Get-ScheduledTaskInfo -TaskName $task}while((!(Test-Path "$out\probe.log") -or $state -eq 'Running') -and [DateTime]::UtcNow -lt $deadline)
 if($state -eq 'Running'){throw 'Topology helper exceeded observation window'}
 $report.task_result=$info.LastTaskResult;$report.passed=($info.LastTaskResult -eq 0)
}catch{$report.error=$_.Exception.Message}
finally{if($registered){Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue;Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue};$report.completed=$true;$report.finished=[DateTime]::UtcNow.ToString('o');$report|ConvertTo-Json|Set-Content "$out\report.json"}
$report|ConvertTo-Json;if(!$report.passed){Get-Content "$out\probe.log" -Tail 8 -ErrorAction SilentlyContinue;exit 1}
