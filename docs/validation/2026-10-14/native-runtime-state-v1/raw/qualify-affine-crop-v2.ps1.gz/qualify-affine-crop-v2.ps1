$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$r="$env:LOCALAPPDATA\npu-render";$b="$r\builds\affine-crop-v2";$out="$r\vm\affine-crop-v2-qualification";$exe="$b\Release\nr_affine_crop_contract.exe"
if(Test-Path $out){throw 'Evidence exists'};$proof=Get-Content "$b\build-report.json" -Raw|ConvertFrom-Json;if(!$proof.clean_build -or (Get-FileHash $exe).Hash -ne $proof.contract_binary_sha256){throw 'Build mismatch'}
New-Item -ItemType Directory $out|Out-Null
$env:PATH="$r\toolchains\openvino-2026.4.1\Lib\site-packages\openvino\libs;$env:PATH";$env:NR_RENDER_NPU_CACHE="$r\vm\model-cache-2026-4-v209";$env:NR_RENDER_SHARED_QUEUE='1';$env:NR_RENDER_MEMORY_CACHE='1';$env:NR_RENDER_COMPACT_COVERAGE='0'
$report=[ordered]@{started=[DateTime]::UtcNow.ToString('o');passed=$false;completed=$false;driver_installed=$false;desktop_changed=$false;runs=@()}
try{foreach($backend in @('CPU','NPU')){
 $p=Start-Process $exe -ArgumentList @($backend) -PassThru -NoNewWindow -RedirectStandardOutput "$out\$backend.stdout.jsonl" -RedirectStandardError "$out\$backend.stderr.log";[void]$p.Handle
 if(!$p.WaitForExit(240000)){$p.Kill();$p.WaitForExit();throw 'Owned test exceeded 240 seconds'};$p.Refresh();$code=$p.ExitCode;$p.Dispose()
 $entry=[ordered]@{backend=$backend;exit_code=$code};$report.runs+=,$entry;if($code){throw 'Crop contract failed'}
 $rows=@(Get-Content "$out\$backend.stdout.jsonl"|Where-Object {$_ -match '^\{.*\}$'}|ForEach-Object {$_|ConvertFrom-Json});$entry.result=@($rows|Where-Object passed)
 if($entry.result.Count -ne 1 -or $entry.result[0].npu_or_cpu_crop_calls -ne 36 -or $entry.result[0].negative_cases -ne 7){throw 'Crop evidence missing'};$report|ConvertTo-Json -Depth 6|Set-Content "$out\report.json"
};$report.passed=$true}catch{$report.error=$_.Exception.Message}
finally{$report.completed=$true;$report.finished=[DateTime]::UtcNow.ToString('o');$report|ConvertTo-Json -Depth 6|Set-Content "$out\report.json"}
Get-Content "$out\report.json";if(!$report.passed){exit 1}
