$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$r="$env:LOCALAPPDATA\npu-render";$b="$r\builds\affine-crop-v1";$out="$r\vm\affine-crop-v1-replay";$trace="$r\vm\native-desktop-admission-v10\T8-NpuRender-NativeTraceV1\draw-17280.bin";$exe="$b\Release\nr_affine_crop.exe"
if(Test-Path $out){throw 'Evidence exists'};$build=Get-Content "$b\build-report.json" -Raw|ConvertFrom-Json;if(!$build.clean_build -or (Get-FileHash $exe).Hash -ne $build.binary_sha256){throw 'Build mismatch'}
if(@(Get-Process nr_registered_local_indexed_worker,nr_registered_draw_replay_probe,nr_registered_linear_texture_draw_test -ErrorAction SilentlyContinue).Count){throw 'Another renderer active'}
New-Item -ItemType Directory $out|Out-Null
$env:PATH="$r\toolchains\openvino-2026.4.1\Lib\site-packages\openvino\libs;$env:PATH";$env:NR_RENDER_NPU_CACHE="$r\vm\model-cache-2026-4-v209";$env:NR_RENDER_SHARED_QUEUE='1';$env:NR_RENDER_PIPELINE_CACHE='expanded';$env:NR_RENDER_MEMORY_CACHE='1';$env:NR_RENDER_COMPACT_COVERAGE='0';$env:NR_RENDER_AFFINE_BATCH='65535';$env:NR_RENDER_OPAQUE_CROP='1'
$report=[ordered]@{started=[DateTime]::UtcNow.ToString('o');passed=$false;completed=$false;driver_installed=$false;desktop_changed=$false;runs=@()};$reference=(Get-FileHash "$r\vm\large-surface-v2-replay\cpu-pixels.bin").Hash
try{
 foreach($backend in @('CPU','NPU')){
  $p=Start-Process $exe -ArgumentList @('--capture',('"'+$trace+'"'),'--backend',$backend,'--output',('"'+$out+'\'+$backend+'-pixels.bin"'),'--repeat','3','--batch','4096') -PassThru -NoNewWindow -RedirectStandardOutput "$out\$backend.stdout.jsonl" -RedirectStandardError "$out\$backend.stderr.log";[void]$p.Handle
  if(!$p.WaitForExit(180000)){$p.Kill();$p.WaitForExit();throw 'Owned replay exceeded 180 seconds'};$p.Refresh();$code=$p.ExitCode;$p.Dispose()
  $entry=[ordered]@{backend=$backend;exit_code=$code;exact_reference=$false};$report.runs+=,$entry;if($code){throw 'Replay failed'}
  $rows=@(Get-Content "$out\$backend.stdout.jsonl"|Where-Object {$_ -match '^\{.*\}$'}|ForEach-Object {$_|ConvertFrom-Json})
  $entry.crop_executions=@($rows|Where-Object opaque_affine_crop).Count;$entry.timings=@($rows|Where-Object kind -eq draw_stage_timing);$entry.pixels_sha256=(Get-FileHash "$out\$backend-pixels.bin").Hash;$entry.exact_reference=$entry.pixels_sha256 -eq $reference
  $report|ConvertTo-Json -Depth 8|Set-Content "$out\report.json";if(!$entry.exact_reference -or $entry.crop_executions -ne 3){throw 'Crop validation failed'}
 }
 $report.passed=$true
}catch{$report.error=$_.Exception.Message}
finally{$report.completed=$true;$report.finished=[DateTime]::UtcNow.ToString('o');$report|ConvertTo-Json -Depth 8|Set-Content "$out\report.json"}
Get-Content "$out\report.json";if(!$report.passed){exit 1}
