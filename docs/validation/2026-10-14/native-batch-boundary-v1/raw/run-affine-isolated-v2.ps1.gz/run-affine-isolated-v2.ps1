$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$r="$env:LOCALAPPDATA\npu-render";$b="$r\builds\affine-isolated-v2";$out="$r\vm\affine-isolated-v2-qualification"
if(Test-Path $out){throw 'Evidence exists'};$proof=Get-Content "$b\build-report.json" -Raw|ConvertFrom-Json;$exe="$b\Release\nr_affine_isolated.exe";if(!$proof.clean_build -or (Get-FileHash $exe).Hash -ne $proof.binary_sha256){throw 'Build mismatch'}
New-Item -ItemType Directory $out|Out-Null
$env:PATH="$r\toolchains\openvino-2026.4.1\Lib\site-packages\openvino\libs;$env:PATH";$env:NR_RENDER_NPU_CACHE="$r\vm\model-cache-2026-4-v209";$env:NR_RENDER_SHARED_QUEUE='1';$env:NR_RENDER_PIPELINE_CACHE='expanded';$env:NR_RENDER_MEMORY_CACHE='1';$env:NR_RENDER_COMPACT_COVERAGE='0'
$report=[ordered]@{started=[DateTime]::UtcNow.ToString('o');completed=$false;passed=$false;driver_installed=$false;desktop_changed=$false;runs=@()}
foreach($batch in @('65535')){
 if($batch -eq 'default'){Remove-Item Env:NR_RENDER_AFFINE_BATCH -ErrorAction SilentlyContinue}else{$env:NR_RENDER_AFFINE_BATCH=$batch}
 foreach($mode in @('linear','linear-opaque','point','point-opaque')){
  $label="$batch-$mode";$arguments=@('NPU');if($mode -ne 'linear'){$arguments+=('--'+$mode)}
  $p=Start-Process $exe -ArgumentList $arguments -PassThru -NoNewWindow -RedirectStandardOutput "$out\$label.stdout.jsonl" -RedirectStandardError "$out\$label.stderr.log";[void]$p.Handle
  $timedOut=!$p.WaitForExit(120000);if($timedOut){$p.Kill();$p.WaitForExit()};$p.Refresh();$code=$p.ExitCode;$p.Dispose()
  $report.runs+=@{batch=$batch;mode=$mode;exit_code=$code;timed_out=$timedOut};$report|ConvertTo-Json -Depth 6|Set-Content "$out\report.json"
 }
}
$report.completed=$true;$report.passed=@($report.runs|Where-Object exit_code -ne 0).Count -eq 0;$report.finished=[DateTime]::UtcNow.ToString('o');$report|ConvertTo-Json -Depth 6|Set-Content "$out\report.json";Get-Content "$out\report.json"
