$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$r="$env:LOCALAPPDATA\npu-render";$b="$r\builds\native-routing-v15b";$out="$r\vm\affine-batches-v1";$trace="$r\vm\native-desktop-admission-v10\T8-NpuRender-NativeTraceV1\draw-17280.bin"
if(Test-Path $out){throw 'Evidence exists'}
$build=Get-Content "$b\registered-build-report.json" -Raw|ConvertFrom-Json;$exe="$b\Release\nr_registered_draw_replay_probe.exe"
if(!$build.clean_build -or (Get-FileHash $exe).Hash -ne $build.binary_sha256.'nr_registered_draw_replay_probe.exe'){throw 'Build mismatch'}
if(@(Get-Process nr_registered_local_indexed_worker,nr_registered_draw_replay_probe -ErrorAction SilentlyContinue).Count){throw 'Another rendering experiment active'}
New-Item -ItemType Directory $out|Out-Null
$env:PATH="$r\toolchains\openvino-2026.4.1\Lib\site-packages\openvino\libs;$env:PATH";$env:NR_RENDER_NPU_CACHE="$r\vm\model-cache-2026-4-v209";$env:NR_RENDER_SHARED_QUEUE='1';$env:NR_RENDER_PIPELINE_CACHE='expanded';$env:NR_RENDER_MEMORY_CACHE='1';$env:NR_RENDER_COMPACT_COVERAGE='0'
$report=[ordered]@{started=[DateTime]::UtcNow.ToString('o');passed=$false;completed=$false;driver_installed=$false;desktop_changed=$false;replays=@()}
$reference=(Get-FileHash "$r\vm\large-surface-v2-replay\cpu-pixels.bin").Hash
try{
 foreach($batch in @('default','65536','262144')){
  if($batch -eq 'default'){Remove-Item Env:NR_RENDER_AFFINE_BATCH -ErrorAction SilentlyContinue}else{$env:NR_RENDER_AFFINE_BATCH=$batch}
  $p=Start-Process $exe -ArgumentList @('--capture',('"'+$trace+'"'),'--backend','NPU','--output',('"'+$out+'\'+$batch+'-pixels.bin"'),'--repeat','3','--batch','4096') -PassThru -NoNewWindow -RedirectStandardOutput "$out\$batch.stdout.jsonl" -RedirectStandardError "$out\$batch.stderr.log";[void]$p.Handle
  if(!$p.WaitForExit(240000)){$p.Kill();$p.WaitForExit();throw 'Owned replay exceeded 240 seconds'};$p.Refresh();$code=$p.ExitCode;$p.Dispose()
  $entry=[ordered]@{batch=$batch;exit_code=$code;exact_reference=$false};$report.replays+=,$entry
  if($code){throw 'Replay failed'};$entry.pixels_sha256=(Get-FileHash "$out\$batch-pixels.bin").Hash;$entry.exact_reference=$entry.pixels_sha256 -eq $reference
  $entry.timings=@(Get-Content "$out\$batch.stdout.jsonl"|Where-Object {$_ -match '^\{.*\}$'}|ForEach-Object {$_|ConvertFrom-Json}|Where-Object kind -eq draw_stage_timing)
  $report|ConvertTo-Json -Depth 8|Set-Content "$out\report.json"
  if(!$entry.exact_reference -or $entry.timings.Count -ne 3){throw 'Replay validation failed'}
 }
 $report.passed=$true
}catch{$report.error=$_.Exception.Message}
finally{Remove-Item Env:NR_RENDER_AFFINE_BATCH -ErrorAction SilentlyContinue;$report.completed=$true;$report.finished=[DateTime]::UtcNow.ToString('o');$report|ConvertTo-Json -Depth 8|Set-Content "$out\report.json"}
Get-Content "$out\report.json";if(!$report.passed){exit 1}
