"""Copy verified native IDD frames into a user-readable, finite presentation relay."""
from native_process_observer_v1 import PinnedProcess
from native_session_broker_v1 import C,W,k,require,obj
from pathlib import Path
from datetime import UTC,datetime
import argparse,time,struct,json,hashlib,traceback
p=argparse.ArgumentParser()
for name in ('transaction','topology','output'):p.add_argument('--'+name,type=Path,required=True)
p.add_argument('--seconds',type=int,default=170);v=p.parse_args();assert 1<=v.seconds<=170
v.output.mkdir(exist_ok=False);out=v.output;report=dict(started=datetime.now(UTC).isoformat(),completed=False,passed=False,published=0,desktop_offloaded=False);peers=[]
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def rows(path):return [json.loads(x) for x in path.read_text(encoding='utf-8-sig').splitlines() if x.startswith('{') and x.endswith('}')]
for name,args,result in [('CreateFileW',[W.LPCWSTR,W.DWORD,W.DWORD,W.LPVOID,W.DWORD,W.DWORD,W.HANDLE],W.HANDLE),('ReadFile',[W.HANDLE,W.LPVOID,W.DWORD,C.POINTER(W.DWORD),W.LPVOID],W.BOOL),('GetFileSizeEx',[W.HANDLE,C.POINTER(C.c_longlong)],W.BOOL),('QueryPerformanceCounter',[C.POINTER(C.c_longlong)],W.BOOL)]:
 f=getattr(k,name);f.argtypes=args;f.restype=result
def bootstrap():
 for attempt in range(5):
  try:return obj(v.transaction/'bootstrap/report.json')
  except json.JSONDecodeError:
   if attempt==4:raise
   time.sleep(.02)
last=None
try:
 state=bootstrap();assert state['admission_published'] and not state['completed']
 assert any(x.get('extension_verified') and x.get('physical_path_preserved') for x in rows(v.topology))
 for key in ('compositor','indirect_host'):
  peer=PinnedProcess(state[key]['pid']);peers.append(peer);assert peer.report()==state[key];peer.verify()
 host=peers[1];report['producer']=host.report();report['compositor']=peers[0].report();counter=C.c_longlong();require(k.QueryPerformanceCounter(C.byref(counter)));earliest=counter.value;report['earliest_qpc']=earliest;save()
 source=Path(__import__('os').environ['ProgramData'])/'T8-NpuRender-NativeIddV1'/f'latest-frame-{host.identity.pid}.bin';deadline=time.perf_counter()+v.seconds
 while time.perf_counter()<deadline and not (out/'stop').exists():
  time.sleep(.1)
  for peer in peers:peer.verify()
  state=bootstrap();assert not state['completed'] and not state.get('error')
  if any(x.get('completed') for x in rows(v.topology)):break
  if not (state.get('actual_dwm_npu_execution') and state.get('preferred_adapter_selected') and state.get('successful_frame_readback')):time.sleep(.1);continue
  handle=k.CreateFileW(str(source),0x80000000,7,None,3,0,None)
  if handle==C.c_void_p(-1).value:
   error=C.get_last_error()
   if error in (2,3):time.sleep(.1);continue
   raise C.WinError(error)
  try:
   size=C.c_longlong();require(k.GetFileSizeEx(handle,C.byref(size)));buf=C.create_string_buffer(64);count=W.DWORD();require(k.ReadFile(handle,buf,64,C.byref(count),None));assert count.value==64
   header=buf.raw;h=struct.unpack('<QIIQIIIIQQII',header);magic,version,hs,seq,w,height,fmt,stride,n,qpc,pid,reserved=h
   assert magic==0x31454d415246524e and version==1 and hs==64 and seq and qpc and pid==host.identity.pid and not reserved
   assert 0<w<=8192 and 0<height<=8192 and w*height<=4*1024*1024 and fmt in (28,87) and stride==w*4 and n==w*height*4 and size.value==64+n
   if qpc<earliest:continue
   if last:
    assert seq>=last[3] and qpc>=last[9]
    if seq==last[3]:assert h==last;continue
    assert qpc>last[9] and h[4:9]==last[4:9]
   pixels=C.create_string_buffer(n);require(k.ReadFile(handle,pixels,n,C.byref(count),None));assert count.value==n
  finally:k.CloseHandle(handle)
  for peer in peers:peer.verify()
  data=header+pixels.raw;temporary=out/'latest.tmp';temporary.write_bytes(data);temporary.replace(out/'latest.bin');last=h
  sample=dict(sequence=seq,qpc=qpc,producer_pid=pid,width=w,height=height,format=fmt,pixel_bytes=n,pixel_sha256=hashlib.sha256(pixels.raw).hexdigest(),packet_sha256=hashlib.sha256(data).hexdigest(),observed=datetime.now(UTC).isoformat(),npu_receipts_observed=state['npu_receipts'],known_stimulus_pixel=list(pixels.raw[(70*w+70)*4:(70*w+70)*4+4]) if w>70 and height>70 else None)
  with (out/'frames.jsonl').open('a') as stream:stream.write(json.dumps(sample)+'\n')
  report['published']+=1;report['latest']=sample;report['producer_and_compositor_verified']=True;save();time.sleep(.1)
 report['passed']=report['published']>0
except Exception as e:report.update(error=repr(e),traceback=traceback.format_exc())
finally:
 for peer in peers:peer.close()
 report.update(completed=True,finished=datetime.now(UTC).isoformat());save()
print(json.dumps(report));raise SystemExit(0 if report['passed'] else 1)
