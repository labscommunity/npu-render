$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$r="$env:LOCALAPPDATA\npu-render";$b="$r\builds\native-routing-v13";$out="$r\vm\cache-retirement-v1"
if(Test-Path $out){throw 'Cache qualification exists'};New-Item -ItemType Directory $out|Out-Null
$exe="$b\Release\nr_registered_provider_memory_cache_test.exe";$proof=Get-Content "$b\registered-build-report.json" -Raw|ConvertFrom-Json
if(!$proof.clean_build -or (Get-FileHash $exe).Hash -ne $proof.binary_sha256.'nr_registered_provider_memory_cache_test.exe'){throw 'Cache test identity mismatch'}
$env:PATH="$r\toolchains\openvino-2026.4.1\Lib\site-packages\openvino\libs;"+$env:PATH;$report=[ordered]@{started=[DateTime]::UtcNow.ToString('o');completed=$false;passed=$false;cases=@();desktop_changed=$false}
try{foreach($backend in @('CPU','NPU')){
 $p=Start-Process $exe -ArgumentList $backend -NoNewWindow -PassThru -RedirectStandardOutput "$out\$backend.stdout.jsonl" -RedirectStandardError "$out\$backend.stderr.log";[void]$p.Handle
 if(!$p.WaitForExit(90000)){$p.Kill();$p.WaitForExit();throw 'Cache contract timeout'};$p.Refresh();$code=$p.ExitCode;$p.Dispose();if($code){throw "$backend cache contract failed"};$receipt=Get-Content "$out\$backend.stdout.jsonl" -Tail 1|ConvertFrom-Json
 if(!$receipt.passed -or $receipt.execution_device -ne $backend -or $receipt.evictions -ne 3){throw 'Cache retirement receipt mismatch'};$report.cases+=$receipt
};$report.passed=$true}catch{$report.error=$_.Exception.Message}
finally{$report.completed=$true;$report.finished=[DateTime]::UtcNow.ToString('o');$report|ConvertTo-Json -Depth 5|Set-Content "$out\report.json"}
$report|ConvertTo-Json -Depth 5;if(!$report.passed){exit 1}
