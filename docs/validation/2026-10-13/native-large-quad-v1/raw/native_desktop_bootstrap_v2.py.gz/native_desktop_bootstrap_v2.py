"""Bounded native indirect-display admission; never disables a physical output."""
from native_session_broker_v2 import *
from native_process_observer_v1 import PinnedProcess,named_processes,find_compositor,find_indirect_host,process_image
import traceback,struct
p=argparse.ArgumentParser()
for n in ('worker','runtime','cache','session_probe','devcon','idd_inf','transaction','trace'):
    p.add_argument('--'+n.replace('_','-'),type=Path,required=True)
v=p.parse_args();out=v.transaction/'bootstrap';out.mkdir(exist_ok=False)
report=dict(started=datetime.now(UTC).isoformat(),passed=False,completed=False,desktop_offloaded=False,physical_frame_presented=False,display_topology_requested=False,actual_dwm_npu_execution=False,actual_umdf_npu_execution=False,controller_pid=os.getpid())
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def logs(path):
    if not path.exists():return []
    return [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.startswith('{') and line.endswith('}')]
def gate():
    result=subprocess.run([str(v.session_probe),'--inspect-session'],capture_output=True,timeout=5,creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode==0 and not result.stderr
    state=json.loads(result.stdout);assert state['ready_for_interactive_task'] and state['signed_in_and_unlocked'] and state['controller_matches_console_user'],'Signed-in unlocked owner console is required'
    return state
state=obj(v.transaction/'ownership.json');assert state['schema']==3 and state['mode']=='native-admission'
assert hashlib.sha256(v.devcon.read_bytes()).hexdigest()==state['devcon_sha256'].lower()
assert len(state['packages'])==2
idd=next(x for x in state['packages'] if x['inf']=='nr_native_indirect_probe.inf')
assert idd['hardware_id']==r'ROOT\NPURENDER_NATIVE_INDIRECT_V1' and hashlib.sha256(v.idd_inf.read_bytes()).hexdigest()==idd['inf_sha256'].lower()
def own_process(handle,role):
    entry=process_identity(handle);image=process_image(handle)
    state.setdefault('owned_processes',[]).append(dict(pid=entry.pid,created=entry.created,image=image,sha256=hashlib.sha256(Path(image).read_bytes()).hexdigest(),role=role))
    temporary=v.transaction/'ownership-python.tmp';temporary.write_text(json.dumps(state,indent=2)+'\n');temporary.replace(v.transaction/'ownership.json')
def remove_indirect():
    result=subprocess.run([str(v.devcon),'remove',idd['hardware_id']],capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'remove.stdout.log').write_bytes(result.stdout);(out/'remove.stderr.log').write_bytes(result.stderr)
    report['indirect_remove_exit']=result.returncode;assert result.returncode==0,'Indirect device removal failed or requested restart'
def frame_header(path,pid):
    # A shared-delete handle follows the publisher's atomic complete-file swap.
    k.CreateFileW.argtypes=[W.LPCWSTR,W.DWORD,W.DWORD,W.LPVOID,W.DWORD,W.DWORD,W.HANDLE];k.CreateFileW.restype=W.HANDLE
    k.ReadFile.argtypes=[W.HANDLE,W.LPVOID,W.DWORD,C.POINTER(W.DWORD),W.LPVOID];k.ReadFile.restype=W.BOOL
    k.GetFileSizeEx.argtypes=[W.HANDLE,C.POINTER(C.c_longlong)];k.GetFileSizeEx.restype=W.BOOL
    handle=k.CreateFileW(str(path),0x80000000,7,None,3,0,None)
    if handle==C.c_void_p(-1).value:
        error=C.get_last_error()
        if error in (2,3):return None
        raise C.WinError(error)
    try:
        size=C.c_longlong();require(k.GetFileSizeEx(handle,C.byref(size)));buffer=C.create_string_buffer(64);count=W.DWORD();require(k.ReadFile(handle,buffer,64,C.byref(count),None));assert count.value==64
        magic,version,header,sequence,width,height,fmt,row,byte_count,qpc,producer,reserved=struct.unpack('<QIIQIIIIQQII',buffer.raw)
        assert magic==0x31454d415246524e and version==1 and header==64 and sequence>0 and producer==pid and reserved==0 and qpc>0
        assert 0<width<=8192 and 0<height<=8192 and width*height<=4*1024*1024 and fmt in (28,87) and row==width*4 and byte_count==width*height*4 and size.value==byte_count+64
        return dict(sequence=sequence,width=width,height=height,format=fmt,pixel_bytes=byte_count,producer_pid=producer,qpc=qpc)
    finally:k.CloseHandle(handle)
worker=None;installer=None;compositor=None;host=None;permissions=[];leases=[];install_attempted=False;streams=[];save()
try:
    session=gate();report['session_gate']=session
    compositor=find_compositor(session['console_session']);report['compositor']=compositor.report()
    assert process_identity(k.GetCurrentProcess()).session==0
    own_process(k.GetCurrentProcess(),'controller')
    baseline=set()
    for pid in named_processes('WUDFHost.exe'):
        peer=PinnedProcess(pid)
        try:baseline.add((peer.identity.pid,peer.identity.created))
        finally:peer.close()
    assert find_indirect_host(set(),0) is None,'Owned indirect host already exists'
    stamp=C.c_uint64();k.GetSystemTimeAsFileTime.argtypes=[W.LPVOID];k.GetSystemTimeAsFileTime(C.byref(stamp))
    for name in ('install.stdout.log','install.stderr.log','worker.stdout.jsonl','worker.stderr.log'):streams.append((out/name).open('xb'))
    install_attempted=True
    installer=subprocess.Popen([str(v.devcon),'install',str(v.idd_inf),idd['hardware_id']],stdin=subprocess.DEVNULL,stdout=streams[0],stderr=streams[1],creationflags=subprocess.CREATE_NO_WINDOW)
    deadline=time.perf_counter()+30
    while host is None:
        assert time.perf_counter()<deadline,'New indirect host did not appear'
        if installer.poll() is not None:assert installer.returncode==0,'Indirect installer exited unsuccessfully'
        host=find_indirect_host(baseline,stamp.value)
        if host is None:time.sleep(.02)
    ready_deadline=time.perf_counter()+8;report['indirect_host']=host.report();report['host_found_after_ms']=(time.perf_counter()-(deadline-30))*1000;save()
    gate();compositor.verify();host.verify()
    suffix=secrets.token_hex(16);pipe=r'\\.\pipe\npu-render-indexed-'+suffix
    env=os.environ.copy();env['PATH']=str(v.runtime)+os.pathsep+env.get('PATH','');env.update(NR_RENDER_NPU_CACHE=str(v.cache),NR_RENDER_SHARED_QUEUE='1',NR_RENDER_PIPELINE_CACHE='expanded',NR_RENDER_MEMORY_CACHE='1',NR_RENDER_COMPACT_COVERAGE='0')
    worker=subprocess.Popen([str(v.worker),pipe,'4096','235',str(compositor.identity.pid),str(compositor.identity.created),str(host.identity.pid),str(host.identity.created)],env=env,stdin=subprocess.DEVNULL,stdout=streams[2],stderr=streams[3],creationflags=subprocess.CREATE_NO_WINDOW)
    own_process(int(worker._handle),'worker');report['worker_pid']=worker.pid;save()
    while not any(x.get('local_worker_ready') for x in logs(out/'worker.stdout.jsonl')):
        assert worker.poll() is None and time.perf_counter()<ready_deadline,'Worker was not ready before native-host admission deadline';time.sleep(.01)
    for handle in (k.GetCurrentProcess(),int(worker._handle)):
        for sid in (compositor.sid,host.sid):permissions.append(ProcessGrant(handle,sid))
    gate();compositor.verify();host.verify();assert time.perf_counter()<ready_deadline
    # Publish compositor first. Host Ready allows DriverEntry and monitor arrival.
    leases.append(LeaseGrant(int(worker._handle),compositor.handle,suffix,scope=1,desktop_session=session['console_session'],milliseconds=240000))
    leases.append(LeaseGrant(int(worker._handle),host.handle,suffix,scope=2,desktop_session=session['console_session'],milliseconds=240000))
    report['admission_published']=True;report['admission_publication_ms']=(time.perf_counter()-(ready_deadline-8))*1000;save()
    deadline=time.perf_counter()+210;last_gate=0
    while time.perf_counter()<deadline:
        compositor.verify();host.verify()
        if time.perf_counter()-last_gate>=1:gate();last_gate=time.perf_counter()
        if installer.poll() is not None:assert installer.returncode==0,'Native indirect installation failed'
        assert worker.poll() is None,'NPU worker stopped before native frame evidence'
        entries=logs(out/'worker.stdout.jsonl');renders=[x for x in entries if x.get('passed') and x.get('execution_device')=='NPU'];acks=[x for x in entries if x.get('worker_success')]
        report['npu_receipts']=len(renders);report['delivery_acknowledgments']=len(acks)
        report['actual_dwm_npu_execution']=any(x.get('client_pid')==compositor.identity.pid for x in renders)
        report['actual_umdf_npu_execution']=any(x.get('client_pid')==host.identity.pid for x in renders)
        events=logs(v.trace/f'process-{host.identity.pid}.jsonl')
        report['native_driver_entry']=any(x.get('event')=='driver_entry' for x in events)
        report['preferred_adapter_selected']=any(x.get('event')=='assigned' and x.get('preferred_selected') for x in events)
        report['successful_frame_readback']=any(x.get('event')=='frame_readback' and x.get('status')=='00000000' for x in events)
        frame=frame_header(v.trace/f'latest-frame-{host.identity.pid}.bin',host.identity.pid)
        if frame:report['latest_frame']=frame
        matched_acks=any(x.get('client_pid')==compositor.identity.pid for x in acks)
        save()
        if frame and report['native_driver_entry'] and report['preferred_adapter_selected'] and report['successful_frame_readback'] and report['actual_dwm_npu_execution'] and matched_acks:
            report['passed']=True;report['native_indirect_frame_produced']=True;break
        time.sleep(.2)
    assert report['passed'],'Native indirect frame evidence incomplete at trial deadline'
except Exception as error:report.update(error=repr(error),traceback=traceback.format_exc())
finally:
    if install_attempted:
        try:remove_indirect()
        except Exception as error:report['remove_error']=repr(error);report['passed']=False
    for lease in reversed(leases):lease.close()
    for grant in reversed(permissions):
        try:grant.restore()
        except Exception as error:report.setdefault('permission_restore_errors',[]).append(repr(error));report['passed']=False
    report['owned_process_acls_restored_exactly']=bool(permissions) and all(x.restored for x in permissions)
    for process,label in ((installer,'installer'),(worker,'worker')):
        if process is not None and process.poll() is None:
            process.kill();process.wait(timeout=5);report[label+'_terminated_after_device_removal']=True
        if process is not None:report[label+'_exit_code']=process.returncode
    for peer in (host,compositor):
        if peer:peer.close()
    for stream in streams:stream.close()
    report.update(completed=True,finished=datetime.now(UTC).isoformat());save()
print(json.dumps(report));raise SystemExit(0 if report['passed'] else 1)
