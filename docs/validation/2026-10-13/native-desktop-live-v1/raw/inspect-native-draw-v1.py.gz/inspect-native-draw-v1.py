from pathlib import Path
import os,struct,json,hashlib
p=Path(os.environ['LOCALAPPDATA'])/'npu-render/vm/native-desktop-admission-v1/T8-NpuRender-NativeTraceV1/draw-1888.bin';data=p.read_bytes();assert data[:8]==b'NPDRAW01';at=8;rows={}
while at<len(data):
 label=data[at:at+32].split(b'\0')[0].decode();n=struct.unpack_from('<Q',data,at+32)[0];at+=40;payload=data[at:at+n];at+=n
 if label in ('arguments','viewport','blend','blend-factor','raster','scissors','target-description'):rows[label]=list(struct.unpack('<'+('f' if label in ('viewport','blend-factor') else 'I')*(n//4),payload))
 else:rows[label]=dict(bytes=n,sha256=hashlib.sha256(payload).hexdigest())
assert at==len(data);print(json.dumps(rows))
