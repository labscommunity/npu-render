$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$r="$env:LOCALAPPDATA\npu-render";$out="$r\vm\native-admission-diagnosis-v1";$b="$r\builds\native-routing-v3";$sdk="$r\toolchains\openvino-2026.4.1\Lib\site-packages\openvino";$trace="$r\vm\native-desktop-admission-v1\T8-NpuRender-NativeTraceV1\draw-1888.bin"
if(Test-Path $out){throw 'Diagnosis evidence exists'}
New-Item -ItemType Directory $out|Out-Null
$env:CMAKE_BUILD_PARALLEL_LEVEL='4';$ErrorActionPreference='Continue'
& cmake --build $b --config Release --target nr_registered_draw_replay_probe *> "$out\build.log";$code=$LASTEXITCODE
$ErrorActionPreference='Stop';if($code){throw 'Offline capture replay build failed'}
$env:PATH="$sdk\libs;"+$env:PATH
$exe="$b\Release\nr_registered_draw_replay_probe.exe"
$process=Start-Process $exe -ArgumentList @('--capture',('"'+$trace+'"'),'--backend','CPU','--output',('"'+$out+'\cpu-pixels.bin"')) -PassThru -NoNewWindow -RedirectStandardOutput "$out\replay.stdout.jsonl" -RedirectStandardError "$out\replay.stderr.log"
[void]$process.Handle
if(!$process.WaitForExit(90000)){$process.Kill();$process.WaitForExit();throw 'Offline replay timed out'};$process.Refresh();$exit=$process.ExitCode;$process.Dispose()
[ordered]@{observed=[DateTime]::UtcNow.ToString('o');build_passed=$true;capture_sha256=(Get-FileHash $trace).Hash;capture_bytes=(Get-Item $trace).Length;binary_sha256=(Get-FileHash $exe).Hash;replay_exit_code=$exit;backend='CPU';driver_installed=$false;desktop_changed=$false}|ConvertTo-Json|Set-Content "$out\report.json"
Get-Content "$out\report.json" -Raw;Get-Content "$out\replay.stdout.jsonl";Get-Content "$out\replay.stderr.log"
