from pathlib import Path
import os,json,collections
r=Path(os.environ['LOCALAPPDATA'])/'npu-render/vm';a=(r/'large-texture-v1-replay/cpu-pixels.bin').read_bytes();b=(r/'native-texture-oracle-v1/npu-pixels.bin.unverified').read_bytes();assert len(a)==len(b)==91*64*4
print(json.dumps({'components':len(a),'different':sum(x!=y for x,y in zip(a,b)),'maximum_error':max(abs(x-y) for x,y in zip(a,b)),'cpu_ranges':[[min(a[c::4]),max(a[c::4])] for c in range(4)],'npu_ranges':[[min(b[c::4]),max(b[c::4])] for c in range(4)],'cpu_unique_colors':len(set(zip(*[a[c::4] for c in range(4)]))),'npu_unique_colors':len(set(zip(*[b[c::4] for c in range(4)])))}))
