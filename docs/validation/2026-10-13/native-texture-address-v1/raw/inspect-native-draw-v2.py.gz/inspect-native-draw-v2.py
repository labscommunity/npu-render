from pathlib import Path
import os,struct,json,hashlib,sys
p=Path(sys.argv[1]);data=p.read_bytes();assert data[:8]==b'NPDRAW01';at=8;rows={}
while at<len(data):
 label=data[at:at+32].split(b'\0')[0].decode();n=struct.unpack_from('<Q',data,at+32)[0];at+=40;payload=data[at:at+n];at+=n
 if label in ('arguments','viewport','blend','blend-factor','raster','scissors','target-description','source-description','sampler-2-0','pixel-shader','vertex-shader'):rows[label]=list(struct.unpack('<'+('f' if label in ('viewport','blend-factor') else 'I')*(n//4),payload))
 else:rows[label]=dict(bytes=n,sha256=hashlib.sha256(payload).hexdigest())
assert at==len(data);print(json.dumps(rows))
