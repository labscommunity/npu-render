from pathlib import Path
import os,struct,json,collections
r=Path(os.environ['LOCALAPPDATA'])/'npu-render/vm';data=(r/'native-desktop-admission-v3/T8-NpuRender-NativeTraceV1/draw-13192.bin').read_bytes();at=8;records={}
while at<len(data):
 label=data[at:at+32].split(b'\0')[0].decode();n=struct.unpack_from('<Q',data,at+32)[0];at+=40;records[label]=data[at:at+n];at+=n
source=records['source'];positions=[(778,1616,187),(778,1632,187),(868,1647,188),(778,1648,187),(778,1664,187),(868,1679,189)]
rows=[]
for x,y,observed in positions:
 i=y*2912+x;row={'index':i,'observed_npu_blue':observed,'actual_blue':source[i*4]}
 row['offset_candidates']={str(delta):source[(i-delta)*4] for delta in (1048576,2097152,4194304) if i>=delta}
 row['mod_candidates']={str(mod):source[(i%mod)*4] for mod in (65536,1048576,2097152,4194304)};rows.append(row)
print(json.dumps(rows))
