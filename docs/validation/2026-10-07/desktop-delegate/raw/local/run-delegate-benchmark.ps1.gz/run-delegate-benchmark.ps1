$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:LOCALAPPDATA 'Temp\npu-graphics-probe-0146a2388f25'
$out=Join-Path $env:LOCALAPPDATA 'npu-render\checks\desktop-delegate-20261007'
$taskName='NpuRender-Delegate-Benchmark-20261007'
$server=$null
$probe=$null
$telemetry=$null
$stop=Join-Path $out 'delegate-telemetry.stop'
if (@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object {$_.LocalPort -in @(18080,19100)}).Count) { throw 'Test ports are in use' }
$sdk='C:\cascadia-inkling\ov\openvino_genai_windows_2026.3.1.0_x86_64'
$env:PATH=(Join-Path $sdk 'runtime\bin\intel64\Release')+';'+(Join-Path $sdk 'runtime\3rdparty\tbb\bin')+';'+$env:PATH
$serverArgs=@('worker','--rank','0','--total','1','--model','C:\prefill-lab\models\Qwen2.5-7B-Instruct-int4-ov','--device','GPU','--engine','ov-genai','--api','127.0.0.1:18080','--listen','127.0.0.1:19100','--cb','--cb-cache-size','1','--cb-max-num-seqs','1','--cb-prefix-caching','false')
$code=@'
import sys,runpy,json
from pathlib import Path
root,out=map(Path,sys.argv[1:])
sys.path.insert(0,str(root/'stack-source'))
fps=60
for stage,rounds,requests,tokens,warmup in [('smoke',1,1,32,0),('sustained',5,3,128,120)]:
    while True:
        print('Starting '+stage+' fps='+str(fps),flush=True)
        report=out/('delegate-'+stage+'-'+str(fps)+'.json')
        sys.argv=[str(root/'benchmark_delegate.py'),'--executable',str(root/'native-build/Release/nr_desktop_delegate.exe'),'--endpoint','http://127.0.0.1:18080/v1','--model','Qwen2.5-7B-Instruct-int4-ov','--inference-device','GPU','--expected-npu-driver','1005540','--conditions','DWM,NPU,GPU,NPU_SELECT','--rounds',str(rounds),'--requests',str(requests),'--max-tokens',str(tokens),'--warmup-seconds',str(warmup),'--fps',str(fps),'--report',str(report)]
        try:
            runpy.run_path(sys.argv[0],run_name='__main__')
            break
        except RuntimeError as error:
            if str(error) != 'delegated trace did not sustain 99% of the requested cadence' or fps!=60:
                raise
            print('60 fps rejected; repeating every condition at matched 30 fps',flush=True)
            fps=30

'@
try {
 $server=Start-Process -FilePath 'C:\cascadia-inkling\cascadia-ov.exe' -ArgumentList $serverArgs -PassThru -RedirectStandardOutput (Join-Path $out 'delegate-server.stdout.log') -RedirectStandardError (Join-Path $out 'delegate-server.stderr.log')
 @{pid=$server.Id;args=$serverArgs;device='GPU';binary_sha256=(Get-FileHash 'C:\cascadia-inkling\cascadia-ov.exe' -Algorithm SHA256).Hash;renderer_sha256=(Get-FileHash (Join-Path $root 'native-build\Release\nr_desktop_delegate.exe') -Algorithm SHA256).Hash;started_utc=[DateTime]::UtcNow.ToString('o');scheme=(powercfg /getactivescheme | Out-String).Trim()} | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 (Join-Path $out 'delegate-server.json')
 $deadline=(Get-Date).AddSeconds(120)
 $ready=$false
 while ((Get-Date) -lt $deadline) {
  if ($server.HasExited) { throw 'Owned Tahoma worker exited' }
  try { $models=Invoke-RestMethod 'http://127.0.0.1:18080/v1/models' -TimeoutSec 2; if ($models.data.Count -gt 0) { $ready=$true; break } } catch {}
  Start-Sleep -Seconds 1
 }
 if (-not $ready) { throw 'Worker readiness timed out' }
 $job=Join-Path $out 'delegate.job.json'
 @{command=@((Join-Path $root 'venv\Scripts\python.exe'),'-c',$code,$root,$out);log=(Join-Path $out 'delegate.log')} | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 $job
 $action=New-ScheduledTaskAction -Execute (Join-Path $root 'venv\Scripts\pythonw.exe') -Argument ('"'+(Join-Path $root 'native_runner.py')+'" "'+$job+'"')
 $principal=New-ScheduledTaskPrincipal -UserId ($env:COMPUTERNAME+'\tatef') -LogonType Interactive -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 25) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
 Register-ScheduledTask -TaskName $taskName -Action $action -Principal $principal -Settings $settings | Out-Null
 $probe=Start-Process -FilePath (Join-Path $root 'native-build\Release\nr_gpu_power_probe.exe') -ArgumentList @('1400',('"'+(Join-Path $out 'delegate-igcl.jsonl')+'"')) -PassThru -RedirectStandardOutput (Join-Path $out 'delegate-igcl.stdout.log') -RedirectStandardError (Join-Path $out 'delegate-igcl.stderr.log')
 if (Test-Path $stop) { Remove-Item $stop }
 $telemetry=Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $root 'windows_gpu_telemetry.ps1'),'-OutputPath',(Join-Path $out 'delegate-gpu.jsonl'),'-Seconds','600','-StopFile',$stop) -PassThru -RedirectStandardOutput (Join-Path $out 'delegate-gpu.stdout.log') -RedirectStandardError (Join-Path $out 'delegate-gpu.stderr.log')
 Start-ScheduledTask -TaskName $taskName
 $deadline=(Get-Date).AddSeconds(1300)
 do {
  @{at_utc=[DateTime]::UtcNow.ToString('o');battery_percent=(Get-CimInstance Win32_Battery).EstimatedChargeRemaining;status=@(Get-CimInstance -Namespace root/wmi -ClassName BatteryStatus | Select-Object PowerOnline,Charging,Discharging,RemainingCapacity,ChargeRate,DischargeRate,Voltage)} | ConvertTo-Json -Depth 6 -Compress | Add-Content -Encoding UTF8 (Join-Path $out 'delegate-battery.jsonl')
  Start-Sleep -Seconds 5
  $state=(Get-ScheduledTask -TaskName $taskName).State
 } while ($state -eq 'Running' -and (Get-Date) -lt $deadline)
 if ($state -eq 'Running') { throw 'Benchmark task timed out' }
 $result=(Get-ScheduledTaskInfo -TaskName $taskName).LastTaskResult
 Get-Content (Join-Path $out 'delegate.log') -Tail 10
 if ($result -ne 0) { throw ('Benchmark task failed: '+$result) }
} finally {
 Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
 Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
 Set-Content -Path $stop -Value 'stop'
 if ($telemetry -and -not $telemetry.HasExited) {
  if (-not $telemetry.WaitForExit(15000)) { Stop-Process -Id $telemetry.Id -Force }
 }
 if ($probe -and -not $probe.HasExited) { Stop-Process -Id $probe.Id -Force }
 if ($server -and -not $server.HasExited) { Stop-Process -Id $server.Id -Force }
 @{stopped_utc=[DateTime]::UtcNow.ToString('o');task_removed=$true;task_result=$result} | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $out 'delegate-cleanup.json')
}
