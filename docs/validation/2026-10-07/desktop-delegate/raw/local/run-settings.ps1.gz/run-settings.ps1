$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:LOCALAPPDATA 'Temp\npu-graphics-probe-0146a2388f25'
$out=Join-Path $env:LOCALAPPDATA 'npu-render\checks\desktop-delegate-20261007'
$taskName='NpuRender-Settings-20261007'
$server=$null
$probe=$null
if (@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object {$_.LocalPort -in @(18080,19100)}).Count) { throw 'Test ports are in use' }
$sdk='C:\cascadia-inkling\ov\openvino_genai_windows_2026.3.1.0_x86_64'
$env:PATH=(Join-Path $sdk 'runtime\bin\intel64\Release')+';'+(Join-Path $sdk 'runtime\3rdparty\tbb\bin')+';'+$env:PATH
$serverArgs=@('worker','--rank','0','--total','1','--model','C:\prefill-lab\models\Qwen2.5-7B-Instruct-int4-ov','--device','GPU','--engine','ov-genai','--api','127.0.0.1:18080','--listen','127.0.0.1:19100','--cb','--cb-cache-size','1','--cb-max-num-seqs','1','--cb-prefix-caching','false')
$code=@'
import sys,runpy
from pathlib import Path
root,out=map(Path,sys.argv[1:])
sys.path.insert(0,str(root/'stack-source'))
for stage,rounds,requests,tokens,warmup in [('smoke',1,1,16,0),('sustained',5,3,128,120)]:
    print('Starting '+stage,flush=True)
    sys.argv=[str(root/'benchmark_native_settings.py'),'--executable',str(root/'nr_native_settings.exe'),'--endpoint','http://127.0.0.1:18080/v1','--model','Qwen2.5-7B-Instruct-int4-ov','--inference-device','GPU','--expected-npu-driver','1005540','--conditions','GPU,NPU_CONV,NPU_EFFICIENT,NPU_ONE_TILE,NPU_ONE_TILE_EFFICIENT,IDLE','--rounds',str(rounds),'--requests',str(requests),'--max-tokens',str(tokens),'--warmup-seconds',str(warmup),'--report',str(out/('settings-'+stage+'.json'))]
    runpy.run_path(sys.argv[0],run_name='__main__')
'@
try {
 $server=Start-Process -FilePath 'C:\cascadia-inkling\cascadia-ov.exe' -ArgumentList $serverArgs -PassThru -RedirectStandardOutput (Join-Path $out 'settings-server.stdout.log') -RedirectStandardError (Join-Path $out 'settings-server.stderr.log')
 @{pid=$server.Id;args=$serverArgs;device='GPU';binary_sha256=(Get-FileHash 'C:\cascadia-inkling\cascadia-ov.exe' -Algorithm SHA256).Hash;renderer_sha256=(Get-FileHash (Join-Path $root 'nr_native_settings.exe') -Algorithm SHA256).Hash;started_utc=[DateTime]::UtcNow.ToString('o');scheme=(powercfg /getactivescheme | Out-String).Trim()} | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 (Join-Path $out 'settings-server.json')
 $deadline=(Get-Date).AddSeconds(120)
 $ready=$false
 while ((Get-Date) -lt $deadline) {
  if ($server.HasExited) { throw 'Owned Tahoma worker exited' }
  try { $models=Invoke-RestMethod 'http://127.0.0.1:18080/v1/models' -TimeoutSec 2; if ($models.data.Count -gt 0) { $ready=$true; break } } catch {}
  Start-Sleep -Seconds 1
 }
 if (-not $ready) { throw 'Worker readiness timed out' }
 $job=Join-Path $out 'settings.job.json'
 @{command=@((Join-Path $root 'venv\Scripts\python.exe'),'-c',$code,$root,$out);log=(Join-Path $out 'settings.log')} | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 $job
 $action=New-ScheduledTaskAction -Execute (Join-Path $root 'venv\Scripts\pythonw.exe') -Argument ('"'+(Join-Path $root 'native_runner.py')+'" "'+$job+'"')
 $principal=New-ScheduledTaskPrincipal -UserId ($env:COMPUTERNAME+'\tatef') -LogonType Interactive -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 25) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
 Register-ScheduledTask -TaskName $taskName -Action $action -Principal $principal -Settings $settings | Out-Null
 $probe=Start-Process -FilePath (Join-Path $root 'native-build\Release\nr_gpu_power_probe.exe') -ArgumentList @('1400',('"'+(Join-Path $out 'settings-igcl.jsonl')+'"')) -PassThru -RedirectStandardOutput (Join-Path $out 'settings-igcl.stdout.log') -RedirectStandardError (Join-Path $out 'settings-igcl.stderr.log')
 Start-ScheduledTask -TaskName $taskName
 $deadline=(Get-Date).AddSeconds(1300)
 do {
  @{at_utc=[DateTime]::UtcNow.ToString('o');battery_percent=(Get-CimInstance Win32_Battery).EstimatedChargeRemaining;status=@(Get-CimInstance -Namespace root/wmi -ClassName BatteryStatus | Select-Object PowerOnline,Charging,Discharging,RemainingCapacity,ChargeRate,DischargeRate,Voltage)} | ConvertTo-Json -Depth 6 -Compress | Add-Content -Encoding UTF8 (Join-Path $out 'settings-battery.jsonl')
  Start-Sleep -Seconds 5
  $state=(Get-ScheduledTask -TaskName $taskName).State
 } while ($state -eq 'Running' -and (Get-Date) -lt $deadline)
 if ($state -eq 'Running') { throw 'Benchmark task timed out' }
 $result=(Get-ScheduledTaskInfo -TaskName $taskName).LastTaskResult
 Get-Content (Join-Path $out 'settings.log') -Tail 10
 if ($result -ne 0) { throw ('Benchmark task failed: '+$result) }
} finally {
 Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
 Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
 if ($probe -and -not $probe.HasExited) { Stop-Process -Id $probe.Id -Force }
 if ($server -and -not $server.HasExited) { Stop-Process -Id $server.Id -Force }
 @{stopped_utc=[DateTime]::UtcNow.ToString('o');task_removed=$true;task_result=$result} | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $out 'settings-cleanup.json')
}
