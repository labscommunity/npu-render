$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:LOCALAPPDATA 'Temp\npu-graphics-probe-0146a2388f25'
$out=Join-Path $env:LOCALAPPDATA 'npu-render\checks\desktop-delegate-20261007'
$task='NpuRender-Delegate-Switch-20261007'
$code=@'
import sys,subprocess,os,runpy
from pathlib import Path
root,out=map(Path,sys.argv[1:])
os.environ['PATH']=str(root/'venv/Lib/site-packages/openvino/libs')+os.pathsep+os.environ['PATH']
for graph in ['source-over','opaque-select']:
    print('Starting '+graph,flush=True)
    command=[str(root/'native-build/Release/nr_desktop_delegate.exe'),'--mode','DWM','--sequence','NPU,INVALID,GPU,DWM','--switch-every','2.5','--seconds','13','--expected-npu-driver','1005540','--npu-graph',graph,'--report',str(out/('delegate-switch-'+graph+'.json'))]
    result=subprocess.run(command,timeout=120)
    if result.returncode: raise SystemExit(result.returncode)
sys.path.insert(0,str(root/'stack-source'))
sys.argv=[str(root/'validate_native_live.py'),'--executable',str(root/'native-build/Release/nr_native_live.exe'),'--npu-alpha','convolution','--report',str(out/'shared-renderer-control.json')]
runpy.run_path(sys.argv[0],run_name='__main__')
'@
try {
 $job=Join-Path $out 'delegate-switch.job.json'
 @{command=@((Join-Path $root 'venv\Scripts\python.exe'),'-c',$code,$root,$out);log=(Join-Path $out 'delegate-switch.log')} | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 $job
 $action=New-ScheduledTaskAction -Execute (Join-Path $root 'venv\Scripts\pythonw.exe') -Argument ('"'+(Join-Path $root 'native_runner.py')+'" "'+$job+'"')
 $principal=New-ScheduledTaskPrincipal -UserId ($env:COMPUTERNAME+'\tatef') -LogonType Interactive -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
 Register-ScheduledTask -TaskName $task -Action $action -Principal $principal -Settings $settings | Out-Null
 Start-ScheduledTask -TaskName $task
 $deadline=(Get-Date).AddSeconds(240)
 do { Start-Sleep -Seconds 3; $state=(Get-ScheduledTask -TaskName $task).State } while ($state -eq 'Running' -and (Get-Date) -lt $deadline)
 if ($state -eq 'Running') { throw 'Switch check timed out' }
 Get-Content (Join-Path $out 'delegate-switch.log') -Tail 20
 if ((Get-ScheduledTaskInfo -TaskName $task).LastTaskResult -ne 0) { throw 'Switch check failed' }
} finally {
 Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
 Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
}
