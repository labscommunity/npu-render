import ctypes as c
from ctypes import wintypes as w
import json,time

u=c.WinDLL('user32',use_last_error=True)
u.OpenInputDesktop.argtypes=[w.DWORD,w.BOOL,w.DWORD];u.OpenInputDesktop.restype=w.HANDLE
u.CloseDesktop.argtypes=[w.HANDLE]
u.GetUserObjectInformationW.argtypes=[w.HANDLE,c.c_int,w.LPVOID,w.DWORD,c.POINTER(w.DWORD)]
u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)]
u.PostMessageW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM];u.PostMessageW.restype=w.BOOL
callback_type=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
u.EnumDesktopWindows.argtypes=[w.HANDLE,callback_type,w.LPARAM];u.EnumDesktopWindows.restype=w.BOOL
def name(handle):
    value=c.create_unicode_buffer(256);length=w.DWORD()
    return value.value if u.GetUserObjectInformationW(handle,2,value,c.sizeof(value),c.byref(length)) else None
report={'action':'request WM_CLOSE on the identified ASUS saver only; no input injection or desktop switching','requests':[]}
handle=u.OpenInputDesktop(0,False,0x41)
report['before']=name(handle) if handle else None
try:
    if handle and report['before']=='Screen-saver':
        @callback_type
        def callback(hwnd,unused):
            pid=w.DWORD();u.GetWindowThreadProcessId(hwnd,c.byref(pid))
            if pid.value==9436:
                report['requests'].append({'pid':pid.value,'posted':bool(u.PostMessageW(hwnd,0x10,0,0))})
            return True
        report['enumerated']=bool(u.EnumDesktopWindows(handle,callback,0))
finally:
    if handle:u.CloseDesktop(handle)
time.sleep(2)
handle=u.OpenInputDesktop(0,False,1)
report['after']=name(handle) if handle else None
if handle:u.CloseDesktop(handle)
print(json.dumps(report))
