$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:LOCALAPPDATA 'Temp\npu-graphics-probe-0146a2388f25'
$out=Join-Path $env:LOCALAPPDATA 'npu-render\checks\desktop-delegate-20261007'
$zip=Join-Path $root 'npu-render-ci-bda4b98.zip'
$build=Join-Path $env:LOCALAPPDATA 'npu-render\builds\ci-bda4b98'
$installed=Join-Path $build 'npu-render'
$task='NpuRender-Delegate-Bundle-20261007'
$expectedZip='91e59836a5857509409b4b4c793bbea9ea5be8fe1a108b82e6d2609abd3f60f9'
if ((Get-FileHash $zip -Algorithm SHA256).Hash.ToLower() -ne $expectedZip) { throw 'Archive checksum mismatch' }
if (Test-Path $build) { throw 'Isolated build destination already exists' }
Expand-Archive -LiteralPath $zip -DestinationPath $build
$manifest=Get-Content (Join-Path $installed 'manifest.json') -Raw | ConvertFrom-Json
if ($manifest.source_revision -ne 'bda4b9835f2a85eb48d2428c9fc67e0161be3905') { throw 'Source revision mismatch' }
$count=0
foreach ($file in $manifest.sha256.PSObject.Properties) {
 if ((Get-FileHash (Join-Path $installed $file.Name) -Algorithm SHA256).Hash.ToLower() -ne $file.Value) { throw ('Manifest mismatch: '+$file.Name) }
 $count++
}
$code=@'
import os,sys,subprocess,json
from pathlib import Path
installed,out=map(Path,sys.argv[1:])
os.environ['PATH']=str(installed/'runtime')+os.pathsep+os.environ['PATH']
report=out/'bundle-switch.json'
command=[str(installed/'nr_desktop_delegate.exe'),'--mode','DWM','--fps','30','--sequence','NPU,INVALID,GPU,DWM','--switch-every','2.5','--seconds','13','--expected-npu-driver','1005540','--report',str(report)]
result=subprocess.run(command,timeout=120)
if result.returncode: raise SystemExit(result.returncode)
r=json.loads(report.read_text())
assert r['passed'] and r['restored_source_windows']==3 and r['end_screen_max_error']==0
assert all(c['maximum_rgb_error']==0 for c in r['screen_checks'])
accepted=[s['requested'] for s in r['selections'] if s['accepted']]
assert accepted==['DWM','NPU','GPU','DWM'],accepted
rejected=[s for s in r['selections'] if not s['accepted']]
assert len(rejected)==1 and rejected[0]['retained']=='NPU'
assert all(f['visible_source_windows']==(3 if f['mode']=='DWM' else 0) for f in r['frames'])
print('Packaged visible handoff and source restoration passed',flush=True)
'@
try {
 $job=Join-Path $out 'bundle-switch.job.json'
 @{command=@((Join-Path $root 'venv\Scripts\python.exe'),'-c',$code,$installed,$out);log=(Join-Path $out 'bundle-switch.log')} | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 $job
 $action=New-ScheduledTaskAction -Execute (Join-Path $root 'venv\Scripts\pythonw.exe') -Argument ('"'+(Join-Path $root 'native_runner.py')+'" "'+$job+'"')
 $principal=New-ScheduledTaskPrincipal -UserId ($env:COMPUTERNAME+'\tatef') -LogonType Interactive -RunLevel Limited
 $settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 3) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
 Register-ScheduledTask -TaskName $task -Action $action -Principal $principal -Settings $settings | Out-Null
 Start-ScheduledTask -TaskName $task
 $deadline=(Get-Date).AddSeconds(150)
 do { Start-Sleep -Seconds 3; $state=(Get-ScheduledTask -TaskName $task).State } while ($state -eq 'Running' -and (Get-Date) -lt $deadline)
 if ($state -eq 'Running') { throw 'Package check timed out' }
 Get-Content (Join-Path $out 'bundle-switch.log') -Tail 12
 if ((Get-ScheduledTaskInfo -TaskName $task).LastTaskResult -ne 0) { throw 'Package check failed' }
 $launcher=Join-Path $env:LOCALAPPDATA 'npu-render\run-delegate.cmd'
 if (Test-Path $launcher) { throw 'Existing launcher would be overwritten' }
 @('@echo off','call "%LOCALAPPDATA%\npu-render\builds\ci-bda4b98\npu-render\run-delegate.cmd" %*') | Set-Content -Encoding ASCII $launcher
 @{source_revision=$manifest.source_revision;bundle_sha256=$expectedZip;verified_files=$count;installed_directory=$installed;launcher=$launcher;checked_utc=[DateTime]::UtcNow.ToString('o');passed=$true} | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $out 'bundle-installation.json')
} finally {
 Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue
 Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue
}
