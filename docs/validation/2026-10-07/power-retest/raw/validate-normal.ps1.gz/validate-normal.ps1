$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$root = Join-Path $env:LOCALAPPDATA 'Temp\npu-graphics-probe-0146a2388f25'
$out = Join-Path $env:LOCALAPPDATA 'npu-render\checks\power-retest-20261007'
if (-not (Test-Path (Join-Path $out 'controls-cleanup.json'))) { throw 'Controls have not completed cleanup' }
if ((Get-Content (Join-Path $out 'controls-sustained.json') -Raw | ConvertFrom-Json).status -ne 'complete') { throw 'Controls did not complete' }
$taskName='NpuRender-PowerRecovery-20261007'
$code=@'
import sys,runpy
from pathlib import Path
root,out=map(Path,sys.argv[1:])
sys.path.insert(0,str(root/'stack-source'))
sys.argv=[str(root/'validate_native_power.py'),'--executable',str(root/'native-build'/'Release'/'nr_native_live.exe'),'--npu-alpha','convolution','--report',str(out/'normal-control.json')]
runpy.run_path(sys.argv[0],run_name='__main__')
'@
$job=Join-Path $out 'normal-control.job.json'
@{command=@((Join-Path $root 'venv\Scripts\python.exe'),'-c',$code,$root,$out);log=(Join-Path $out 'normal-control.log')} | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 $job
$action=New-ScheduledTaskAction -Execute (Join-Path $root 'venv\Scripts\pythonw.exe') -Argument ('"'+(Join-Path $root 'native_runner.py')+'" "'+$job+'"')
$principal=New-ScheduledTaskPrincipal -UserId ($env:COMPUTERNAME+'\tatef') -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 3) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
try {
 Register-ScheduledTask -TaskName $taskName -Action $action -Principal $principal -Settings $settings | Out-Null
 Start-ScheduledTask -TaskName $taskName
 $deadline=(Get-Date).AddSeconds(150)
 do { Start-Sleep -Seconds 2; $state=(Get-ScheduledTask -TaskName $taskName).State } while ($state -eq 'Running' -and (Get-Date) -lt $deadline)
 if ($state -eq 'Running') { throw 'Normal control timeout' }
 Get-Content (Join-Path $out 'normal-control.log')
 $report=Get-Content (Join-Path $out 'normal-control.json') -Raw | ConvertFrom-Json
 if (-not $report.passed) { throw 'Normal control validation failed' }
} finally {
 Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
 Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
}
