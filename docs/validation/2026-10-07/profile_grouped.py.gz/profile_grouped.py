import json,os,sys,time
from pathlib import Path
import numpy as np
import openvino as ov
root=Path(os.environ['LOCALAPPDATA'])/'Temp'/'npu-graphics-probe-0146a2388f25'
sys.path.insert(0,str(root/'stack-source'))
from npu_render.openvino_diagnostics import inspect_stack,require_npu_driver
from compiler_probe import fixture

core=ov.Core()
report={'stack':inspect_stack(core),'case':'channels_4','source':[1280,720],
        'scope':'Profiled host tensors; no shared D3D12 buffers, inference contention or presentation'}
require_npu_driver(report['stack'],'1005540')
model,values,expected,tolerance=fixture('channels_4',1280,720,32)
compiled=core.compile_model(model,'NPU',{'NPU_COMPILER_TYPE':'PLUGIN','PERF_COUNT':True})
devices=compiled.get_property('EXECUTION_DEVICES')
report['actual_devices']=[devices] if isinstance(devices,str) else list(devices)
assert report['actual_devices'] and all(d.split('.')[0]=='NPU' for d in report['actual_devices'])
report['actual_compiler']=str(compiled.get_property('NPU_COMPILER_TYPE'))
q=compiled.create_infer_request();times=[];maximum=0
for _ in range(6):
 start=time.perf_counter();observed=q.infer(values)[0].copy();times.append((time.perf_counter()-start)*1000)
 assert np.isfinite(observed).all()
 maximum=max(maximum,float(np.abs(observed.astype(np.float64)-expected).max()))
report.update(infer_copy_ms=times,max_byte_error=maximum,passed=maximum<=tolerance)
report['profiling']=[{'name':x.node_name,'type':x.node_type,'exec_type':x.exec_type,
                      'real_ms':x.real_time.total_seconds()*1000,'cpu_ms':x.cpu_time.total_seconds()*1000,
                      'status':str(x.status)} for x in q.get_profiling_info()]
print(json.dumps(report,indent=2),flush=True)
sys.exit(int(not report['passed']))
